function showContact(plage) {
    location.href = "RDV.php";
    document.cookie = "test1=" +"$" + plage + "";

}

function showChat() {
    location.href = "chat.php";
}