<?php
header('Location: reserver.php');
die;
?>