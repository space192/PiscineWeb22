<script src="NavBarStatique.js"></script>
<link rel="stylesheet" href="NavBarStatique.css">